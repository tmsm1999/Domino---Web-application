module.exports.headers = {
	plain: {
		'Content-Type': 'application/javascript',
		'Cache-Control': 'no-cache',
		'Access-Control-Allow-Origin': '*'
	},
	sse: {
		'Content-Type': 'text/event-stream',
		'Cache-Control': 'no-cache',
		'Access-Control-Allow-Origin': '*',
		'Connection': 'keep-alive'
	}
};